// Shared by the wizard and the ownership tree: server message plus its field-level details,
// e.g. "Validation failed — emailAddress: must be a well-formed email address".
export function failMsg(err, fallback) {
  const base = err?.friendlyMessage || err?.message || fallback;
  const details = Array.isArray(err?.details) ? err.details : [];
  return details.length ? `${base} — ${details.join('; ')}` : base;
}
