import { useEffect, useMemo, useRef, useState } from 'react';
import {
  createBoRecord,
  createLegalPerson,
  getOwnershipTree,
  listLegalPersons,
  saveSeniorManagingOfficial,
  updateLegalPersonProfile,
  updateNodeControl,
  uploadDocument,
} from '../api/bovsApi.js';
import OwnershipTree from '../components/OwnershipTree.jsx';
import { controlBasisLabel } from '../data/records.js';
import {
  ID_TYPE_CONFIG, inferIdType, isDirectHolder, ownershipTypeOf, personMissing, today,
} from '../data/uboForm.js';
import { failMsg } from '../utils/errors.js';
import Field from '../components/Field.jsx';
import PersonFields from '../components/PersonFields.jsx';
import './UboRegistration.css';

/* ==========================================================================
   UBO registration — guided process, then one final submit to the checker
   10.1 Customer  ->  10.2/10.3 Ownership structure  ->  10.4 Control
   ->  10.5 Senior managing official fallback  ->  10.6 Verify each UBO  ->  Submit
   ========================================================================== */

const STEPS = [
  { key: 'customer', title: 'Customer', ref: '10.1' },
  { key: 'structure', title: 'Ownership structure', ref: '10.2 – 10.3' },
  { key: 'control', title: 'Control & UBOs', ref: '10.4' },
  { key: 'fallback', title: 'Fallback', ref: '10.5' },
  { key: 'verify', title: 'Verify each UBO', ref: '10.6' },
  { key: 'submit', title: 'Review & submit', ref: 'Final' },
];

// Step index by key, so reordering STEPS cannot silently break navigation.
const S = Object.fromEntries(STEPS.map((st, i) => [st.key, i]));

const customerLabel = (lp) => `${lp.name} (${lp.registrationNumber})`;

const ENTITY_TYPES = [
  { value: 'SHARE_COMPANY', label: 'Share Company' },
  { value: 'PRIVATE_LIMITED_COMPANY', label: 'Private Limited Company' },
  { value: 'PARTNERSHIP', label: 'Partnership' },
  { value: 'OTHER_LEGAL_ARRANGEMENT', label: 'Other legal arrangement' },
];

const EMPTY_CUSTOMER = {
  name: '',
  registrationNumber: '',
  entityType: 'SHARE_COMPANY',
  tin: '',
  countryOfIncorporation: '',
  natureOfBusiness: '',
  directorsAndManagement: '',
};

const CUSTOMER_REQUIRED = [
  ['name', 'Company name'],
  ['registrationNumber', 'Registration number'],
  ['tin', 'TIN'],
  ['countryOfIncorporation', 'Country of incorporation'],
  ['natureOfBusiness', 'Nature of business'],
  ['directorsAndManagement', 'Directors and senior management'],
];

const EMPTY_SMO = { name: '', position: '', justification: '' };

const pct = (v) => String(Number(v ?? 0));

const emptySubjectForm = (subject) => ({
  fullName: subject.holder?.fullName || subject.smo?.name || '',
  gender: '',
  dateOfBirth: '',
  placeOfBirth: '',
  residentialStatus: 'RESIDENT',
  emailAddress: '',
  phoneNumber: '',
  occupation: '',
  dateOfIssue: '',
  sourceOfInformation: 'CUSTOMER',
  additionalInformation: '',
  idDocumentType: inferIdType(subject.holder?.idNumber),
  idVerificationStatus: 'PENDING',
  idTypeDetail: '',
  idNumber: subject.holder?.idNumber || '',
  nationality: subject.holder?.nationality || '',
  residentialAddress: '',
  countryOfIssue: '',
  dateOfExpiry: '',
  dateBecameBo: today(),
  pep: false,
  pepDetails: '',
  sanctionsScreened: false,
  sourceOfWealth: '',
  sourceOfFunds: '',
  file: null,
  evidence: [], // supporting documents: shareholder register, agreements, proof of address ...
});

/* ---------- Stepper ---------- */
function Stepper({ step, onGo }) {
  return (
    <ol className="stepper">
      {STEPS.map((s, i) => {
        const reachable = i < step;
        return (
          <li
            key={s.key}
            className={`step${i === step ? ' active' : ''}${i < step ? ' done' : ''}`}
            aria-current={i === step ? 'step' : undefined}
          >
            <button
              type="button"
              className="step-btn"
              disabled={!reachable}
              aria-label={`${s.title}${reachable ? ' (completed, go back)' : ''}`}
              onClick={() => onGo(i)}
              style={{
                background: 'none', border: 0, padding: 0, font: 'inherit', color: 'inherit',
                display: 'flex', alignItems: 'center', gap: 'inherit', textAlign: 'left',
                cursor: reachable ? 'pointer' : 'default',
              }}
            >
              <span className="step-num" aria-hidden="true">{i < step ? '✓' : i + 1}</span>
              <span className="step-text">
                <span className="step-title">{s.title}</span>
                <span className="step-ref">{s.ref}</span>
              </span>
            </button>
          </li>
        );
      })}
    </ol>
  );
}

/* ==========================================================================
   Main wizard
   ========================================================================== */
export default function UboRegistration() {
  const [step, setStep] = useState(0);
  const [error, setError] = useState(null);
  const [busy, setBusy] = useState(false);
  const [showErrors, setShowErrors] = useState(false); // inline field errors after a failed Continue
  const [customerQuery, setCustomerQuery] = useState('');
  const errorRef = useRef(null);
  const panelRef = useRef(null);
  const treeReq = useRef(0); // ignore out-of-order tree responses
  const firstRender = useRef(true);

  /* 10.1 customer */
  const [legalPersons, setLegalPersons] = useState([]);
  const [mode, setMode] = useState('existing'); // existing | new
  const [legalPersonId, setLegalPersonId] = useState('');
  const [customer, setCustomer] = useState(EMPTY_CUSTOMER);

  /* tree + control + fallback */
  const [tree, setTree] = useState(null);
  const [controlDraft, setControlDraft] = useState({}); // holderKey -> { controlBasis, controlNotes, dirty }
  const [smo, setSmo] = useState(EMPTY_SMO);

  /* 10.6 verification + final submit */
  const [subjects, setSubjects] = useState([]);
  const [forms, setForms] = useState({});
  const [confirmed, setConfirmed] = useState(false);
  const [results, setResults] = useState({}); // key -> { status, ref, error, docWarning }

  /* ---------- load customers ---------- */
  useEffect(() => {
    listLegalPersons({ size: 200, sort: 'name' })
      .then((res) => {
        const list = res.content || [];
        setLegalPersons(list);
        if (list.length === 0) setMode('new');
      })
      .catch((err) => setError(failMsg(err, 'Failed to load customers')));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const selectCustomer = (lp) => {
    setLegalPersonId(lp.id);
    setCustomer({
      name: lp.name || '',
      registrationNumber: lp.registrationNumber || '',
      entityType: lp.entityType || 'SHARE_COMPANY',
      tin: lp.tin || '',
      countryOfIncorporation: lp.countryOfIncorporation || '',
      natureOfBusiness: lp.natureOfBusiness || '',
      directorsAndManagement: lp.directorsAndManagement || '',
    });
  };

  /* ---------- refresh the tree when entering steps 3-6 ---------- */
  const refreshTree = async () => {
    const reqId = ++treeReq.current;
    const t = await getOwnershipTree(legalPersonId);
    if (reqId !== treeReq.current) return t;
    setTree(t);
    setControlDraft((d) => {
      const next = { ...d };
      t.holders.forEach((h) => {
        if (!next[h.key] || !next[h.key].dirty) {
          next[h.key] = { controlBasis: h.controlBasis, controlNotes: '', dirty: false };
        }
      });
      return next;
    });
    return t;
  };

  useEffect(() => {
    if (step >= S.control && legalPersonId) {
      refreshTree().catch((err) => setError(failMsg(err, 'Failed to load ownership structure')));
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [step, legalPersonId]);

  const go = (i) => {
    setError(null);
    setShowErrors(false);
    setStep(i);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  // Show the error where the user is looking, and keep focus management for screen readers.
  useEffect(() => {
    if (error) errorRef.current?.focus(); // focus() also scrolls the banner into view
  }, [error]);
  useEffect(() => {
    if (firstRender.current) { firstRender.current = false; return; }
    panelRef.current?.focus({ preventScroll: true });
  }, [step]);

  const run = async (fn) => {
    setBusy(true);
    setError(null);
    try {
      await fn();
    } catch (err) {
      setError(failMsg(err, 'Action failed'));
    } finally {
      setBusy(false);
    }
  };

  /* ==========================================================================
     Step actions
     ========================================================================== */
  const nextFromCustomer = () => run(async () => {
    if (mode === 'existing' && !legalPersonId) throw new Error('Select the customer first.');
    const missing = CUSTOMER_REQUIRED.filter(([k]) => !String(customer[k] || '').trim()).map(([, l]) => l);
    if (missing.length) throw new Error(`Please complete: ${missing.join(', ')}`);
    if (mode === 'new') {
      const created = await createLegalPerson(customer);
      setLegalPersons((l) => [...l, created]);
      setLegalPersonId(created.id);
      setMode('existing');
    } else {
      // Only write when something actually changed.
      const lp = legalPersons.find((c) => c.id === legalPersonId);
      const editable = ['tin', 'countryOfIncorporation', 'natureOfBusiness', 'directorsAndManagement'];
      if (editable.some((k) => (lp?.[k] || '') !== customer[k])) {
        await updateLegalPersonProfile(legalPersonId, Object.fromEntries(editable.map((k) => [k, customer[k]])));
      }
    }
    setTree(null);
    go(S.structure);
  });

  const nextFromStructure = () => {
    if (!tree || tree.shareholders.length === 0) {
      setError('Add at least one shareholder before continuing.');
      return;
    }
    // Tracing must reach natural persons (10.3); do not let an incomplete structure through.
    if (tree.warnings.length > 0) {
      setError(`Finish tracing before continuing: ${tree.warnings.join('; ')}`);
      return;
    }
    go(S.control);
  };

  const saveControl = async (holder) => {
    const d = controlDraft[holder.key];
    const t = await updateNodeControl(legalPersonId, holder.ownershipNodeId, {
      controlBasis: d.controlBasis,
      controlNotes: d.controlNotes || null,
    });
    setTree(t);
    setControlDraft((x) => ({ ...x, [holder.key]: { ...d, dirty: false } }));
  };

  const nextFromControl = () => run(async () => {
    if (!tree) throw new Error('Load the ownership structure before assessing control.');

    // Persist any control decisions before asking the server to recalculate UBO status.
    for (const h of tree.holders) {
      if (controlDraft[h.key]?.dirty && !h.registered) await saveControl(h);
    }

    // The refreshed server result is authoritative for effective ownership and UBO qualification.
    const t = await refreshTree();
    const identifiedUbo = t.holders.some((h) => h.ubo);

    if (identifiedUbo) {
      go(S.verify);
      return;
    }

    // A senior-managing-official fallback is not a general escape hatch for incomplete data.
    // Only proceed when the backend says the jurisdiction/policy permits it.
    if (t.seniorManagingOfficialAllowed) {
      go(S.fallback);
      return;
    }

    throw new Error(
      'No qualifying UBO was identified and the senior managing official fallback is not permitted. ' +
      'Review the ownership/control evidence or escalate for compliance review.'
    );
  });

  const submitSmo = () => run(async () => {
    setTree(await saveSeniorManagingOfficial(legalPersonId, smo));
    setSmo(EMPTY_SMO);
  });

  const nextFromFallback = () => {
    if (!tree) {
      setError('Load the ownership structure before continuing.');
      return;
    }

    // If a UBO is identified, the fallback should not be used instead of verifying that person.
    if (tree.holders.some((h) => h.ubo)) {
      go(S.verify);
      return;
    }

    if (!tree.seniorManagingOfficialAllowed) {
      setError('The fallback is not permitted for this case. Resolve the ownership/control assessment or escalate for compliance review.');
      return;
    }

    if (!tree.seniorManagingOfficial) {
      setError('Record the senior managing official and document the reasonable measures taken before continuing.');
      return;
    }

    go(S.verify);
  };

  /* Build the list of people to verify when entering step 5 */
  useEffect(() => {
    if (step !== S.verify || !tree) return;
    // keep people already submitted in this session in the list, so the whole batch stays visible
    const list = tree.holders.filter((h) => h.ubo && (!h.registered || results[h.key]?.status === 'created'))
      .map((h) => ({ key: h.key, kind: 'ubo', holder: h }));
    if (list.length === 0 && tree.seniorManagingOfficialAllowed && tree.seniorManagingOfficial) {
      list.push({ key: 'smo', kind: 'smo', smo: tree.seniorManagingOfficial });
    }
    setSubjects(list);
    setForms((f) => {
      const next = { ...f };
      list.forEach((s) => { if (!next[s.key]) next[s.key] = emptySubjectForm(s); });
      return next;
    });
  }, [step, tree, results]);

  const setForm = (key, patch) => setForms((f) => ({ ...f, [key]: { ...f[key], ...patch } }));

  const incomplete = useMemo(
    () => subjects.filter((s) => results[s.key]?.status !== 'created'
      && forms[s.key] && personMissing(forms[s.key]).length > 0),
    [subjects, forms, results],
  );

  const nextFromVerify = () => {
    if (subjects.length === 0) {
      setError('There is no beneficial owner to register for this customer.');
      return;
    }
    if (incomplete.length > 0) {
      setShowErrors(true);
      setError(`Complete the verification details for: ${incomplete.map((s) => forms[s.key].fullName || 'person').join(', ')}`);
      return;
    }
    go(S.submit);
  };

  /* ---------- FINAL SUBMIT ---------- */
  const finalSubmit = () => run(async () => {
    if (!confirmed) throw new Error('Please confirm the declaration before submitting.');
    const nextResults = { ...results };
    for (const s of subjects) {
      if (nextResults[s.key]?.status === 'created') continue;
      const f = forms[s.key];
      const ownershipPart = s.kind === 'ubo'
        ? {
          ownershipNodeId: s.holder.ownershipNodeId,
          ownershipType: ownershipTypeOf(s.holder),
          ownershipPercentage: Number(s.holder.effectivePercentage),
        }
        : {
          capacity: 'SENIOR_MANAGING_OFFICIAL',
          ownershipType: 'CONTROL_BY_OTHER_MEANS',
          ownershipPercentage: 0,
        };
      try {
        const created = await createBoRecord({
          legalPersonId,
          fullName: f.fullName.trim(),
          gender: f.gender,
          dateOfBirth: f.dateOfBirth,
          placeOfBirth: f.placeOfBirth.trim(),
          residentialStatus: f.residentialStatus,
          emailAddress: f.emailAddress.trim(),
          phoneNumber: f.phoneNumber.trim(),
          occupation: f.occupation.trim(),
          dateOfIssue: f.dateOfIssue,
          sourceOfInformation: f.sourceOfInformation,
          additionalInformation: f.additionalInformation || null,
          idDocumentType: f.idDocumentType,
          idVerificationStatus: f.idVerificationStatus,
          idTypeDetail: ID_TYPE_CONFIG[f.idDocumentType]?.detailLabel ? f.idTypeDetail.trim() : null,
          idNumber: f.idNumber.trim(),
          nationality: f.nationality.trim(),
          residentialAddress: f.residentialAddress.trim(),
          countryOfIssue: f.countryOfIssue.trim(),
          dateOfExpiry: f.dateOfExpiry,
          dateBecameBo: f.dateBecameBo,
          pep: f.pep,
          pepDetails: f.pep ? f.pepDetails : null,
          sourceOfWealth: f.sourceOfWealth || null,
          sourceOfFunds: f.sourceOfFunds || null,
          sanctionsScreened: f.sanctionsScreened,
          ...ownershipPart,
        }, true);
        let docWarning = null;
        for (const file of [f.file, ...f.evidence].filter(Boolean)) {
          try {
            await uploadDocument(created.id, file);
          } catch {
            docWarning = 'Record submitted, but a document upload failed — upload it again from the record page.';
          }
        }
        nextResults[s.key] = { status: 'created', ref: created.boReference, docWarning };
      } catch (err) {
        nextResults[s.key] = { status: 'error', error: failMsg(err, 'Failed to submit') };
      }
      setResults({ ...nextResults });
    }
    setResults(nextResults);
  });

  const reset = () => {
    setStep(0); setTree(null); setSubjects([]); setForms({}); setResults({}); setConfirmed(false);
    setControlDraft({}); setSmo(EMPTY_SMO); setError(null); setShowErrors(false);
    setMode(legalPersons.length > 0 ? 'existing' : 'new');
    setLegalPersonId(''); setCustomer(EMPTY_CUSTOMER); setCustomerQuery('');
  };

  const allCreated = subjects.length > 0 && subjects.every((s) => results[s.key]?.status === 'created');
  const anyFailed = subjects.some((s) => results[s.key]?.status === 'error');

  // Warn before the tab is closed with unsaved work in the wizard.
  useEffect(() => {
    if (step === S.customer || allCreated) return undefined;
    const warn = (e) => { e.preventDefault(); e.returnValue = ''; };
    window.addEventListener('beforeunload', warn);
    return () => window.removeEventListener('beforeunload', warn);
  }, [step, allCreated]);

  /* ==========================================================================
     Render
     ========================================================================== */
  const nav = ({ onNext, nextLabel = 'Continue', hideBack, disabled }) => (
    <div className="wizard-nav">
      {!hideBack && step > S.customer && !allCreated
        ? <button type="button" className="btn btn-outline" disabled={busy} onClick={() => go(step === S.verify && tree?.holders.some((h) => h.ubo) ? S.control : step - 1)}>Back</button>
        : <span />}
      {onNext && (
        <button type="button" className="btn btn-blue" disabled={busy || disabled} onClick={onNext}>
          {busy ? 'Please wait…' : nextLabel}
        </button>
      )}
    </div>
  );

  return (
    <div className="ubo-registration">
      <div className="page-head">
        <div>
          <h1>UBO registration</h1>
          <div className="desc">
            Identify the customer, trace the ownership structure to the natural person(s), examine control,
            verify each UBO, then submit once for checker approval.
          </div>
        </div>
      </div>

      <Stepper step={step} onGo={go} />
      {error && <div ref={errorRef} tabIndex={-1} role="alert" className="banner-error"><span>{error}</span></div>}

      <section ref={panelRef} tabIndex={-1} aria-label={STEPS[step].title} style={{ outline: 'none' }}>
      {(step === S.control || step === S.fallback) && !tree && !error && (
        <div className="hint" role="status">Loading ownership structure…</div>
      )}

      {/* ===================== 10.1 Customer ===================== */}
      {step === S.customer && (
        <div className="form-card">
          <h3>10.1 Identify the customer / legal entity</h3>
          <div className="hint">All fields are required to complete customer identification.</div>

          <div className="segmented">
            <button type="button" className={mode === 'existing' ? 'active' : ''}
              disabled={legalPersons.length === 0}
              onClick={() => { setMode('existing'); setCustomer(EMPTY_CUSTOMER); setLegalPersonId(''); setCustomerQuery(''); }}>
              Existing customer
            </button>
            <button type="button" className={mode === 'new' ? 'active' : ''}
              onClick={() => { setMode('new'); setCustomer(EMPTY_CUSTOMER); setLegalPersonId(''); }}>
              New customer
            </button>
          </div>

          {mode === 'existing' && (
            <Field label="Customer" required>
              <input list="customer-options" autoComplete="off" value={customerQuery}
                placeholder="Type a name or registration number, then pick from the list"
                onChange={(e) => {
                  const q = e.target.value;
                  setCustomerQuery(q);
                  const lp = legalPersons.find((c) => customerLabel(c) === q);
                  if (lp) selectCustomer(lp);
                  else { setLegalPersonId(''); setCustomer(EMPTY_CUSTOMER); }
                }} />
              <datalist id="customer-options">
                {legalPersons.map((lp) => <option key={lp.id} value={customerLabel(lp)} />)}
              </datalist>
            </Field>
          )}

          <div className="grid-3">
            <Field label="Company name" required>
              <input value={customer.name} disabled={mode === 'existing'}
                onChange={(e) => setCustomer({ ...customer, name: e.target.value })} />
            </Field>
            <Field label="Registration number" required>
              <input className="mono" value={customer.registrationNumber} disabled={mode === 'existing'}
                onChange={(e) => setCustomer({ ...customer, registrationNumber: e.target.value })} />
            </Field>
            <Field label="Entity type" required>
              <select value={customer.entityType} disabled={mode === 'existing'}
                onChange={(e) => setCustomer({ ...customer, entityType: e.target.value })}>
                {ENTITY_TYPES.map((t) => <option key={t.value} value={t.value}>{t.label}</option>)}
              </select>
            </Field>
          </div>
          <div className="grid-3">
            <Field label="TIN" required>
              <input className="mono" value={customer.tin} onChange={(e) => setCustomer({ ...customer, tin: e.target.value })} />
            </Field>
            <Field label="Country of incorporation" required>
              <input value={customer.countryOfIncorporation}
                onChange={(e) => setCustomer({ ...customer, countryOfIncorporation: e.target.value })} />
            </Field>
            <Field label="Nature of business" required>
              <input value={customer.natureOfBusiness}
                onChange={(e) => setCustomer({ ...customer, natureOfBusiness: e.target.value })} />
            </Field>
          </div>
          <Field label="Directors and senior management" required>
            <textarea rows={3} style={{ width: '100%', font: 'inherit' }}
              placeholder="e.g. Mr. X (Chairman), Ms. Y (CEO), Mr. Z (Director)" value={customer.directorsAndManagement}
              onChange={(e) => setCustomer({ ...customer, directorsAndManagement: e.target.value })} />
          </Field>
          {nav({ onNext: nextFromCustomer, hideBack: true })}
        </div>
      )}

      {/* ===================== 10.2 / 10.3 Structure ===================== */}
      {step === S.structure && (
        <>
          <div className="hint" style={{ marginBottom: 12 }}>
            <strong>10.2 – 10.3</strong> Do not register a company as the final UBO. Add each shareholder; for a
            company, use “+ Shareholder” to keep tracing through every layer until you reach natural persons.
          </div>
          <OwnershipTree legalPersonId={legalPersonId} canEdit onTreeChange={setTree} />
          <div className="form-card">{nav({ onNext: nextFromStructure })}</div>
        </>
      )}

      {/* ===================== 10.4 Control & UBO assessment ===================== */}
      {step === S.control && tree && (
        <div className="form-card">
          <h3>10.4 Examine control, not only percentage ownership</h3>
          <div className="hint">
            Effective ownership is calculated for you (threshold {pct(tree.thresholdPercentage)}%). A person is also a UBO
            if control is exercised by other means, even below the threshold — tick the control basis that applies.
          </div>
          {tree.holders.length === 0 && <div className="hint">No natural persons found yet. Go back and trace the structure further.</div>}
          {tree.holders.map((h) => {
            const d = controlDraft[h.key] || { controlBasis: [], controlNotes: '', dirty: false };
            const toggle = (c) => setControlDraft((x) => {
              const cur = x[h.key] || d;
              const basis = cur.controlBasis.includes(c) ? cur.controlBasis.filter((k) => k !== c) : [...cur.controlBasis, c];
              return { ...x, [h.key]: { ...cur, dirty: true, controlBasis: basis } };
            });
            return (
              <div key={h.key} className={`holder-card${h.ubo ? ' holder-card--ubo' : ''}`}>
                <div className="holder-head">
                  <div>
                    <strong>{h.fullName}</strong>
                    <div className="hint" style={{ margin: 0 }}>{[h.idNumber, h.nationality].filter(Boolean).join(' · ')}</div>
                  </div>
                  <div className="holder-pct"><strong>{pct(h.effectivePercentage)}%</strong><span>effective</span></div>
                  <div>
                    {h.qualifiesByOwnership && <span className="chip chip-ubo">Ownership UBO</span>}
                    {(h.qualifiesByControl || d.controlBasis.length > 0) && <span className="chip chip-control">Control</span>}
                    {!h.ubo && d.controlBasis.length === 0 && <span className="chip chip-muted">Below threshold</span>}
                    {h.registered && <span className="chip chip-muted">Already registered {h.beneficialOwnerReference}</span>}
                  </div>
                </div>
                {h.paths.map((p, i) => <div key={i} className="chain">{p.chain} <b>= {pct(p.percentage)}%</b></div>)}
                {!h.registered && (
                  <>
                    <div className="checkbox-grid">
                      {Object.entries(controlBasisLabel).map(([k, label]) => (
                        <label key={k} className="checkbox-item">
                          <input type="checkbox" checked={d.controlBasis.includes(k)} onChange={() => toggle(k)} />
                          <span>{label}</span>
                        </label>
                      ))}
                    </div>
                    {d.controlBasis.length > 0 && (
                      <Field label="Control details">
                        <input placeholder="e.g. clause 4 of the shareholders' agreement"
                          value={d.controlNotes}
                          onChange={(e) => setControlDraft((x) => ({ ...x, [h.key]: { ...(x[h.key] || d), dirty: true, controlNotes: e.target.value } }))} />
                      </Field>
                    )}
                  </>
                )}
              </div>
            );
          })}
          {nav({ onNext: nextFromControl, nextLabel: 'Save & continue' })}
        </div>
      )}

      {/* ===================== 10.5 Senior managing official ===================== */}
      {step === S.fallback && tree && (
        <div className="form-card">
          <h3>10.5 Senior managing official fallback</h3>
          {!tree.seniorManagingOfficialAllowed ? (
            <div className="banner-warning"><span>
              The senior managing official fallback is not permitted for this case. If no UBO is identified, review the
              ownership/control evidence and escalate for compliance review rather than recording an automatic fallback.
            </span></div>
          ) : (
            <>
              <div className="hint">
                No natural person owns or controls the customer after the measures taken. Record the appropriate senior
                managing official and the capacity. This does not make the CEO the UBO automatically; it is a CDD fallback
                after reasonable measures.
              </div>
              {tree.seniorManagingOfficial && (
                <div className="smo-summary">
                  <strong>{tree.seniorManagingOfficial.name}</strong> — {tree.seniorManagingOfficial.position}
                  <div className="hint" style={{ margin: '4px 0 0' }}>{tree.seniorManagingOfficial.justification}</div>
                </div>
              )}
              <div className="grid-2" style={{ marginTop: 14 }}>
                <Field label="Name" required>
                  <input value={smo.name} onChange={(e) => setSmo({ ...smo, name: e.target.value })} />
                </Field>
                <Field label="Position / capacity" required>
                  <input value={smo.position} onChange={(e) => setSmo({ ...smo, position: e.target.value })} />
                </Field>
              </div>
              <Field label="Reasonable measures taken" required>
                <textarea rows={3} style={{ width: '100%', font: 'inherit' }}
                  placeholder="What was done to identify the controlling natural person, and why it failed"
                  value={smo.justification} onChange={(e) => setSmo({ ...smo, justification: e.target.value })} />
              </Field>
              <button type="button" className="btn btn-outline" disabled={busy || !smo.name || !smo.position || !smo.justification}
                onClick={submitSmo}>
                {tree.seniorManagingOfficial ? 'Update senior managing official' : 'Record senior managing official'}
              </button>
            </>
          )}
          {nav({ onNext: nextFromFallback })}
        </div>
      )}

      {/* ===================== 10.6 Verify each UBO ===================== */}
      {step === S.verify && (
        <div>
          <div className="hint" style={{ marginBottom: 12 }}>
            <strong>10.6</strong> For each beneficial owner, obtain and verify identity, ownership, PEP, sanctions and
            source-of-wealth information. Ownership %, direct/indirect, chain and control basis are calculated from the structure.
          </div>
          {subjects.length === 0 && <div className="form-card"><div className="hint" style={{ margin: 0 }}>
            No unregistered beneficial owner found for this customer.</div></div>}

          {subjects.map((s, idx) => {
            const f = forms[s.key];
            if (!f) return null;
            if (results[s.key]?.status === 'created') {
              return (
                <div key={s.key} className="form-card">
                  <div className="holder-head">
                    <h3 style={{ margin: 0 }}>{idx + 1}. {f.fullName}</h3>
                    <span className="chip chip-ubo">Already submitted · {results[s.key].ref}</span>
                  </div>
                </div>
              );
            }
            const miss = personMissing(f);
            const set = (patch) => setForm(s.key, patch);
            const h = s.holder;
            return (
              <div key={s.key} className="form-card">
                <div className="holder-head">
                  <h3 style={{ margin: 0 }}>
                    {idx + 1}. {f.fullName || (s.kind === 'smo' ? 'Senior managing official' : 'Beneficial owner')}
                    {s.kind === 'smo' && <span className="chip chip-control">Fallback</span>}
                  </h3>
                  <span className={`chip ${miss.length === 0 ? 'chip-ubo' : 'chip-muted'}`}>
                    {miss.length === 0 ? 'Complete' : `${miss.length} missing`}
                  </span>
                </div>

                <div className="derived-box">
                  {h ? (
                    <>
                      <div><strong>{pct(h.effectivePercentage)}%</strong> effective ·{' '}
                        {isDirectHolder(h) ? 'Direct' : 'Indirect'} · {h.qualifiesByOwnership ? 'Ownership' : 'Control'} basis</div>
                      {h.paths.map((p, i) => <div key={i} className="chain">{p.chain} <b>= {pct(p.percentage)}%</b></div>)}
                      {h.controlBasis.length > 0 && (
                        <div className="chain">Control: {h.controlBasis.map((c) => controlBasisLabel[c] || c).join(', ')}</div>
                      )}
                    </>
                  ) : (
                    <div><strong>{s.smo.position}</strong> — recorded as the senior managing official (CDD fallback), not as a UBO.</div>
                  )}
                </div>

                <PersonFields f={f} set={set} idKey={s.key} showFile showErrors={showErrors} />
                <Field label="Supporting evidence (optional, several files allowed)">
                  <input type="file" multiple
                    onChange={(e) => set({ evidence: Array.from(e.target.files || []) })} />
                  <div className="hint" style={{ margin: '4px 0 0' }}>
                    Retained as documentary evidence: shareholder register, shareholders' / voting agreements,
                    nominee declarations, proof of address, source-of-wealth documents.
                  </div>
                </Field>
                {miss.length > 0 && <div className="hint">Still needed: {miss.join(', ')}.</div>}
              </div>
            );
          })}
          <div className="form-card">{nav({ onNext: nextFromVerify, nextLabel: 'Review' })}</div>
        </div>
      )}

      {/* ===================== Review & final submit ===================== */}
      {step === S.submit && (
        <div className="form-card">
          <h3>Review and submit</h3>
          <div className="hint">Submitting sends every beneficial owner below to a checker for verification. A checker cannot approve a record they submitted themselves.</div>

          <div className="review-block">
            <div className="hint">Customer</div>
            <div><strong>{customer.name}</strong> · {customer.registrationNumber} · TIN {customer.tin}</div>
            <div>{customer.countryOfIncorporation} · {customer.natureOfBusiness}</div>
            <div>Directors / senior management: {customer.directorsAndManagement}</div>
          </div>

          {tree?.warnings.length > 0 && (
            <div className="banner-warn"><strong>Tracing notes</strong>
              <ul>{tree.warnings.map((w, i) => <li key={i}>{w}</li>)}</ul></div>
          )}

          {subjects.map((s) => {
            const f = forms[s.key];
            const r = results[s.key];
            const h = s.holder;
            const files = [f.file, ...f.evidence].filter(Boolean);
            return (
              <div key={s.key} className="holder-card">
                <div className="holder-head">
                  <div>
                    <strong>{f.fullName}</strong>
                    <div className="hint" style={{ margin: 0 }}>{f.idNumber}</div>
                  </div>
                  <span className="chip chip-muted">
                    {s.kind === 'smo' ? 'Senior managing official' : (h.qualifiesByOwnership ? 'Ownership' : 'Control')}
                  </span>
                </div>
                {h && h.paths.map((p, i) => <div key={i} className="chain">{p.chain} <b>= {pct(p.percentage)}%</b></div>)}
                {h && h.controlBasis.length > 0 && (
                  <div className="chain">Control: {h.controlBasis.map((c) => controlBasisLabel[c] || c).join(', ')}</div>
                )}
                <div className="hint" style={{ margin: '6px 0 0' }}>
                  Ownership: {h ? `${pct(h.effectivePercentage)}%` : '—'} · PEP: {f.pep ? 'Yes' : 'No'} ·
                  Sanctions: {f.sanctionsScreened ? 'Screened' : '—'} · {files.length} file(s){f.file ? ` (${f.file.name})` : ''}
                </div>
                {r?.status === 'created' && (
                  <div style={{ marginTop: 6 }}>
                    <span className="chip chip-ubo">Submitted</span> <span className="mono">{r.ref}</span>
                    {r.docWarning && <div className="tree-warn" style={{ margin: 0 }}>{r.docWarning}</div>}
                  </div>
                )}
                {r?.status === 'error' && <div className="tree-warn" style={{ margin: '6px 0 0' }}>{r.error}</div>}
              </div>
            );
          })}

          {!allCreated && (
            <label className="checkbox-item" style={{ margin: '14px 0' }}>
              <input type="checkbox" checked={confirmed} onChange={(e) => setConfirmed(e.target.checked)} />
              <span>I confirm the information is adequate, accurate and up to date, and that reasonable measures were taken to verify the identity and beneficial-owner status of each person above.</span>
            </label>
          )}

          {allCreated ? (
            <>
              <div className="banner-success"><span>All beneficial owners were submitted for checker approval.</span></div>
              <div className="wizard-nav"><span /><button type="button" className="btn btn-blue" onClick={reset}>Register another customer</button></div>
            </>
          ) : (
            nav({ onNext: finalSubmit, nextLabel: anyFailed ? 'Retry failed' : 'Submit for approval', disabled: !confirmed })
          )}
        </div>
      )}
      </section>
    </div>
  );
}
