# BOIVS UBO registration flow — updated patch

This patch updates the UBO wizard's transition logic to match the reviewed flow:

1. Identify the legal-entity customer.
2. Build and complete the ownership tree; resolve all backend warnings before proceeding.
3. Assess every natural-person holder for effective ownership and control.
4. Save control decisions and refresh the ownership tree so server-calculated UBO status is authoritative.
5. If one or more UBOs are identified, proceed to verify them.
6. If no UBO is identified, use the senior managing official fallback only when the backend policy flag `seniorManagingOfficialAllowed` permits it; require the official record and reasonable-measures justification.
7. If no UBO is identified and fallback is not permitted, stop and escalate for compliance review.
8. Verify identity and screening data, review, and submit with supporting evidence.

## Files

- `UboRegistration.jsx`: updated control/fallback transition checks and fallback messaging.
- `OwnershipTree.jsx`, `PersonFields.jsx`, `uboForm.js`, `errors.js`, `UboRegistration.css`: included from the supplied patch for context; no unrelated behavior changes were made.

## Integration notes

- This remains a source patch, not a complete runnable app. Keep the existing API modules and surrounding components from your application.
- `refreshTree()` and the backend must remain authoritative for effective ownership, control, threshold, warnings, and `seniorManagingOfficialAllowed`.
- The fallback flag must be computed by jurisdiction-specific compliance policy; do not set it merely because no shareholder crossed an ownership threshold.
- The patch cannot establish legal compliance by itself. Confirm the applicable jurisdiction and run backend/API plus UI integration tests.
