package dashen.bank.boivs.service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.math.BigDecimal;

import org.junit.jupiter.api.Test;

import dashen.bank.boivs.domain.enums.EntityType;
import dashen.bank.boivs.domain.enums.Sector;
import dashen.bank.boivs.service.BoThresholdPolicy.Mode;
import dashen.bank.boivs.service.BoThresholdPolicy.Stake;

class BoThresholdPolicyTest {

    private final BoThresholdPolicy policy = new BoThresholdPolicy(new BigDecimal("25"));

    private static BigDecimal d(String v) {
        return new BigDecimal(v);
    }

    private static Stake direct(String own, String profit, String dissolution, String voting, String debt,
                                boolean preferential) {
        return Stake.root().through(d(own), profit == null ? null : d(profit), dissolution == null ? null : d(dissolution),
                voting == null ? null : d(voting), debt == null ? null : d(debt), preferential);
    }

    @Test
    void thresholdsPerEntityTypeAndSector() {
        assertEquals(0, d("10").compareTo(policy.resolve(EntityType.SHARE_COMPANY, Sector.OTHER).threshold()));
        assertEquals(0, d("10").compareTo(policy.resolve(EntityType.SHARE_COMPANY, null).threshold()));
        for (Sector s : new Sector[] {Sector.MINING, Sector.REAL_ESTATE, Sector.MOTOR_DEALERSHIP, Sector.IMPORT_EXPORT}) {
            assertEquals(0, d("5").compareTo(policy.resolve(EntityType.SHARE_COMPANY, s).threshold()), s.name());
        }
        assertEquals(0, d("5").compareTo(policy.resolve(EntityType.PRIVATE_LIMITED_COMPANY, null).threshold()));
        assertEquals(0, d("2").compareTo(policy.resolve(EntityType.FINANCIAL_INSTITUTION, null).threshold()));
        for (EntityType t : new EntityType[] {EntityType.GENERAL_PARTNERSHIP, EntityType.LIMITED_PARTNERSHIP,
                EntityType.LIMITED_LIABILITY_PARTNERSHIP, EntityType.PPP}) {
            assertEquals(0, d("25").compareTo(policy.resolve(t, null).threshold()), t.name());
        }
    }

    @Test
    void uncoveredTypesAndForeignUseFallback() {
        for (EntityType t : new EntityType[] {EntityType.FOREIGN_LEGAL_PERSON, EntityType.PUBLIC_LIMITED_COMPANY,
                EntityType.TRUST}) {
            assertEquals(Mode.FALLBACK, policy.resolve(t, null).mode(), t.name());
            assertEquals(0, d("25").compareTo(policy.resolve(t, null).threshold()), t.name());
        }
    }

    @Test
    void inclusiveThresholdAndRoundingTolerance() {
        var rule = policy.resolve(EntityType.SHARE_COMPANY, Sector.OTHER);
        assertTrue(policy.qualifiesByOwnership(rule, d("10")));
        assertTrue(policy.qualifiesByOwnership(rule, d("9.99999999")));
        assertFalse(policy.qualifiesByOwnership(rule, d("9.9")));
    }

    @Test
    void indirectHoldingIsMultipliedThroughTheChainAndAddedToDirect() {
        var rule = policy.resolve(EntityType.SHARE_COMPANY, Sector.OTHER);
        Stake holdco = Stake.root().through(d("20"), null, null, null, null, false);
        Stake indirect = holdco.through(d("50"), null, null, null, null, false); // 50% of a 20% holder = 10%
        assertEquals(0, d("10").compareTo(indirect.ownership()));
        assertTrue(policy.qualifiesByOwnership(rule, indirect));
        assertTrue(policy.qualifiesByOwnership(rule, direct("4", null, null, null, null, false).plus(indirect)));
        assertFalse(policy.qualifiesByOwnership(rule, direct("4", null, null, null, null, false)));
    }

    @Test
    void preferentialSharesAndConvertibleDebtOnlyWhereTheRuleHasThem() {
        var share = policy.resolve(EntityType.SHARE_COMPANY, Sector.OTHER);
        var mining = policy.resolve(EntityType.SHARE_COMPANY, Sector.MINING);
        var plc = policy.resolve(EntityType.PRIVATE_LIMITED_COMPANY, null);
        var fi = policy.resolve(EntityType.FINANCIAL_INSTITUTION, null);
        assertTrue(policy.qualifiesByOwnership(share, direct("1", null, null, null, null, true)));
        assertFalse(policy.qualifiesByOwnership(plc, direct("1", null, null, null, null, true)));
        assertTrue(policy.qualifiesByOwnership(share, direct("0", null, null, null, "10", false)));
        assertFalse(policy.qualifiesByOwnership(share, direct("0", null, null, null, "9", false)));
        assertTrue(policy.qualifiesByOwnership(mining, direct("0", null, null, null, "5", false)));
        assertTrue(policy.qualifiesByOwnership(fi, direct("0", null, null, null, "2", false)));
        assertFalse(policy.qualifiesByOwnership(plc, direct("0", null, null, null, "50", false)));
    }

    @Test
    void partnershipsTestProfitDissolutionAndVotingSeparately() {
        var gp = policy.resolve(EntityType.GENERAL_PARTNERSHIP, null);
        assertTrue(policy.qualifiesByOwnership(gp, direct("10", "10", "10", "25", null, false)));
        assertTrue(policy.qualifiesByOwnership(gp, direct("10", "10", "30", "10", null, false)));
        assertFalse(policy.qualifiesByOwnership(gp, direct("30", "10", "10", "10", null, false)));
        assertTrue(policy.qualifiesByOwnership(gp, direct("30", null, null, null, null, false))); // defaults follow ownership
        var llp = policy.resolve(EntityType.LIMITED_LIABILITY_PARTNERSHIP, null);
        assertFalse(policy.qualifiesByOwnership(llp, direct("10", "10", "10", "90", null, false))); // voting not an LLP test
        assertTrue(policy.qualifiesByOwnership(llp, direct("10", "25", "10", null, null, false)));
        var ppp = policy.resolve(EntityType.PPP, null);
        assertTrue(policy.qualifiesByOwnership(ppp, direct("10", null, "25", null, null, false)));
    }

    @Test
    void jointHoldingFlagsAndCombinedStake() {
        var share = policy.resolve(EntityType.SHARE_COMPANY, Sector.OTHER);
        assertTrue(share.jointAllowed());
        assertTrue(policy.resolve(EntityType.PRIVATE_LIMITED_COMPANY, null).jointAllowed());
        assertTrue(policy.resolve(EntityType.FINANCIAL_INSTITUTION, null).jointAllowed());
        assertFalse(policy.resolve(EntityType.GENERAL_PARTNERSHIP, null).jointAllowed());
        Stake combined = direct("6", null, null, null, null, false).plus(direct("5", null, null, null, null, false));
        assertTrue(policy.qualifiesByOwnership(share, combined));
    }

    @Test
    void oneMemberPlcOwnerQualifiesByAnyHolding() {
        var rule = policy.resolve(EntityType.ONE_MEMBER_PLC, null);
        assertEquals(Mode.OWNER_PLUS_MANAGER, rule.mode());
        assertNull(rule.threshold());
        assertTrue(policy.qualifiesByOwnership(rule, Stake.root()));
        assertFalse(policy.qualifiesByOwnership(rule, Stake.zero()));
    }
}
