# BOIVS UBO Registration UI/UX patch

## Included
- `UboRegistration.jsx` — six-step UBO registration wizard, with the enterprise stylesheet imported.
- `OwnershipTree.jsx` — fixed duplicate/incomplete component block and tightened shareholder reference validation.
- `UboRegistration.css` — responsive enterprise styling using dark navy / blue, accessible focus states, clearer forms, cards, statuses, and mobile layouts.
- `PersonFields.jsx`, `uboForm.js`, `errors.js` — included unchanged for context.

## Workflow retained from the supplied source
1. Customer (10.1)
2. Ownership structure (10.2–10.3)
3. Control & UBO assessment (10.4)
4. Senior managing official fallback (10.5)
5. Verify each UBO (10.6)
6. Review and submit to Checker

## Integration
This is a patch for the supplied source files, not a complete runnable application. Keep the existing API modules, `Field.jsx`, `records.js`, and the rest of your app. `UboRegistration.css` is imported by `UboRegistration.jsx`; the root component now uses the `ubo-registration` class so styles are scoped.

## Validation performed
The five JavaScript/JSX files passed a TypeScript transpile syntax check. A full application build, backend/API integration test, and browser visual regression test could not be run because the upload did not include the package manifest, the rest of the application, or test setup.

## Reference image
No reference image was included in `files.zip`; the workflow above is therefore retained from the source code. Supply the reference screenshot separately if the UI must match its exact layout and sequence.
