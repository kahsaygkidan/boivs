// Local calendar date (YYYY-MM-DD). toISOString() is UTC and returns yesterday for the first
// hours of the day in UTC+3.
export const today = () => new Date().toLocaleDateString('en-CA');

export const ID_DOCUMENT_TYPES = [
  { value: 'FAYDA_ID', label: 'Fayda ID' },
  { value: 'PASSPORT', label: 'Passport' },
  { value: 'DRIVING_LICENCE', label: "Driver's License" },
  { value: 'TIN', label: 'TIN' },
  { value: 'KEBELE_ID', label: 'Kebele ID' },
  { value: 'OTHER', label: 'Other' },
];

/**
 * What the form asks for once an ID type is chosen.
 * numeric: digits only. detailLabel: a second input is shown as well (both number and text).
 */
export const ID_TYPE_CONFIG = {
  FAYDA_ID: {
    numberLabel: 'Fayda number (FAN / FIN)', placeholder: '12 to 16 digits', numeric: true,
    test: (v) => /^\d{12,16}$/.test(v), error: 'Fayda number (12 to 16 digits)',
  },
  PASSPORT: {
    numberLabel: 'Passport number', placeholder: 'e.g. EP1234567', upper: true,
    test: (v) => /^[A-Za-z0-9]{6,12}$/.test(v), error: 'Passport number (6 to 12 letters or digits)',
  },
  DRIVING_LICENCE: {
    numberLabel: "Driver's license number", placeholder: 'License number',
    test: (v) => /^[A-Za-z0-9/-]{4,30}$/.test(v), error: "Driver's license number",
  },
  TIN: {
    numberLabel: 'TIN', placeholder: '10 digits', numeric: true,
    test: (v) => /^\d{10}$/.test(v), error: 'TIN (10 digits)',
  },
  KEBELE_ID: {
    numberLabel: 'Kebele ID number', placeholder: 'Kebele ID number',
    detailLabel: 'Kebele / Woreda', detailPlaceholder: 'e.g. Kebele 05, Bole',
    test: (v) => /^[A-Za-z0-9/-]{3,30}$/.test(v), error: 'Kebele ID number',
  },
  OTHER: {
    numberLabel: 'Document number', placeholder: 'Document number',
    detailLabel: 'Document name / type', detailPlaceholder: 'e.g. Residence permit',
    test: (v) => v.length >= 3, error: 'Document number',
  },
};

export const ID_VERIFICATION_STATUSES = [
  { value: 'VERIFIED', label: 'Verified' },
  { value: 'PENDING', label: 'Pending' },
  { value: 'NOT_VERIFIED', label: 'Not Verified' },
];

export const SOURCES_OF_INFORMATION = [
  { value: 'CUSTOMER', label: 'Customer' },
  { value: 'GOVERNMENT_REGISTRY', label: 'Government Registry' },
  { value: 'OFFICIAL_DOCUMENT', label: 'Official Document' },
  { value: 'OTHER', label: 'Other' },
];

/**
 * The ownership tree stores one free-text ID number with no type. Guess the type from the number so
 * a passport number is not prefilled under "Fayda ID" and immediately fail its check. Only a prefill:
 * the officer can still change it.
 */
export function inferIdType(number, fallback = 'FAYDA_ID') {
  const v = (number || '').trim();
  if (!v || ID_TYPE_CONFIG[fallback]?.test(v)) return fallback;
  return ['FAYDA_ID', 'TIN', 'PASSPORT'].find((t) => ID_TYPE_CONFIG[t].test(v)) || fallback;
}

/* ---------- ownership type sent to the backend ---------- */

// Prefer the server's own flag; the chain-string count is only a fallback.
export const isDirectHolder = (h) => (typeof h.direct === 'boolean'
  ? h.direct
  : h.paths?.length === 1 && (h.paths[0].chain.match(/ → /g) || []).length === 1);

/**
 * NOTE: 'DIRECT' must exist in the backend enum next to 'INDIRECT' and 'CONTROL_BY_OTHER_MEANS'.
 * If your enum names differ, change them here only.
 */
export function ownershipTypeOf(h) {
  if (!h.qualifiesByOwnership && h.qualifiesByControl) return 'CONTROL_BY_OTHER_MEANS';
  return isDirectHolder(h) ? 'DIRECT' : 'INDIRECT';
}

/* ---------- validation (10.6) ---------- */

const PHONE = /^\+?[\d\s()-]{7,20}$/;

/** Field key -> message for everything still wrong or missing. */
export function personErrors(f, { requireFile = true } = {}) {
  const e = {};
  const t = today();
  if (!f.fullName.trim()) e.fullName = 'Full name';
  if (!f.gender) e.gender = 'Gender';
  if (!f.dateOfBirth) e.dateOfBirth = 'Date of birth';
  else if (f.dateOfBirth >= t) e.dateOfBirth = 'Date of birth (must be in the past)';
  if (!f.placeOfBirth.trim()) e.placeOfBirth = 'Place of birth';
  if (!/^\S+@\S+\.\S+$/.test(f.emailAddress.trim())) e.emailAddress = 'A valid email address';
  if (!PHONE.test(f.phoneNumber.trim())) e.phoneNumber = 'A valid telephone number';
  if (!f.occupation.trim()) e.occupation = 'Occupation / profession';
  if (!f.dateOfIssue) e.dateOfIssue = 'ID date of issue';
  else if (f.dateOfIssue > t) e.dateOfIssue = 'ID date of issue (cannot be in the future)';
  else if (f.dateOfExpiry && f.dateOfIssue >= f.dateOfExpiry) e.dateOfIssue = 'ID issue date before expiry date';
  const idCfg = ID_TYPE_CONFIG[f.idDocumentType];
  if (!idCfg?.test(f.idNumber.trim())) e.idNumber = idCfg?.error || 'ID number';
  if (idCfg?.detailLabel && !f.idTypeDetail.trim()) e.idTypeDetail = idCfg.detailLabel;
  if (!f.nationality.trim()) e.nationality = 'Nationality';
  if (!f.residentialAddress.trim()) e.residentialAddress = 'Residential address';
  if (!f.countryOfIssue.trim()) e.countryOfIssue = 'Country of issue';
  if (!f.dateOfExpiry) e.dateOfExpiry = 'ID expiry date';
  else if (f.dateOfExpiry < t) e.dateOfExpiry = 'A valid (non-expired) ID document';
  if (!f.dateBecameBo) e.dateBecameBo = 'Date became BO';
  if (f.idVerificationStatus !== 'VERIFIED' && !f.additionalInformation.trim()) {
    e.idVerificationStatus = 'ID marked Verified (or explain in additional information)';
  }
  if (requireFile && !f.file) e.file = 'Verified ID document';
  if (f.pep && !f.pepDetails.trim()) e.pepDetails = 'PEP details';
  if (f.pep && !f.sourceOfWealth.trim()) e.sourceOfWealth = 'Source of wealth (required for PEP)';
  if (!f.sanctionsScreened) e.sanctionsScreened = 'Sanctions screening confirmation';
  return e;
}

/** Labels of everything still missing for a person (unchanged signature). */
export const personMissing = (f, opts) => Object.values(personErrors(f, opts));
