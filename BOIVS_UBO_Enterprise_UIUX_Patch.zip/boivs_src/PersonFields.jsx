import Field from './Field.jsx';
import {
  ID_DOCUMENT_TYPES,
  ID_TYPE_CONFIG,
  ID_VERIFICATION_STATUSES,
  SOURCES_OF_INFORMATION,
  personErrors,
  today,
} from '../data/uboForm.js';

const Err = ({ id, msg }) => (msg
  ? <div id={id} style={{ color: '#b42318', fontSize: 12, marginTop: 4 }}>Needed: {msg}</div>
  : null);

/**
 * Personal, identification, screening and source-of-information fields of a beneficial owner.
 * Shared by the registration wizard (showFile) and the maker's edit form.
 * showErrors: show inline messages (turn on after the first failed attempt to continue).
 */
export default function PersonFields({ f, set, idKey, showFile = false, showErrors = false }) {
  const errs = showErrors ? personErrors(f, { requireFile: showFile }) : {};
  const cid = (k) => `${idKey}-${k}`;
  const bind = (k) => ({
    id: cid(k),
    'aria-invalid': errs[k] ? true : undefined,
    'aria-describedby': errs[k] ? `${cid(k)}-err` : undefined,
  });
  const err = (k) => <Err id={`${cid(k)}-err`} msg={errs[k]} />;
  const text = (k, extra = {}) => (
    <input {...bind(k)} autoComplete="off" value={f[k]} onChange={(e) => set({ [k]: e.target.value })} {...extra} />
  );
  const select = (k, options, placeholder) => (
    <select {...bind(k)} value={f[k]} onChange={(e) => set({ [k]: e.target.value })}>
      {placeholder && <option value="">{placeholder}</option>}
      {options.map((o) => <option key={o.value} value={o.value}>{o.label}</option>)}
    </select>
  );
  const cfg = ID_TYPE_CONFIG[f.idDocumentType] || ID_TYPE_CONFIG.OTHER;

  return (
    <>
      <div className="grid-3">
        <Field label="Full name" required>{text('fullName')}{err('fullName')}</Field>
        <Field label="Date of birth" required>{text('dateOfBirth', { type: 'date', max: today() })}{err('dateOfBirth')}</Field>
        <Field label="Nationality" required>{text('nationality')}{err('nationality')}</Field>
      </div>
      <div className="grid-3">
        <Field label="Gender" required>
          {select('gender', [{ value: 'MALE', label: 'Male' }, { value: 'FEMALE', label: 'Female' }], 'Select…')}
          {err('gender')}
        </Field>
        <Field label="Place of birth" required>{text('placeOfBirth')}{err('placeOfBirth')}</Field>
        <Field label="Residential status" required>
          {select('residentialStatus', [{ value: 'RESIDENT', label: 'Resident' }, { value: 'NON_RESIDENT', label: 'Non-resident' }])}
        </Field>
      </div>
      <div className="grid-3">
        <Field label="Email address" required>{text('emailAddress', { type: 'email' })}{err('emailAddress')}</Field>
        <Field label="Telephone number" required>{text('phoneNumber', { type: 'tel' })}{err('phoneNumber')}</Field>
        <Field label="Occupation / profession" required>{text('occupation')}{err('occupation')}</Field>
      </div>
      <div className="grid-2">
        <Field label="ID document type" required>
          {/* Keep the number if it is also valid for the new type; focus stays on the select so
              keyboard users can keep arrowing through the options. */}
          <select {...bind('idDocumentType')} value={f.idDocumentType} onChange={(e) => {
            const type = e.target.value;
            const keep = ID_TYPE_CONFIG[type]?.test(f.idNumber.trim());
            set({ idDocumentType: type, idNumber: keep ? f.idNumber : '', idTypeDetail: '' });
          }}>
            {ID_DOCUMENT_TYPES.map((t) => <option key={t.value} value={t.value}>{t.label}</option>)}
          </select>
        </Field>
        <Field label="ID verification status" required>
          {select('idVerificationStatus', ID_VERIFICATION_STATUSES)}
          {err('idVerificationStatus')}
        </Field>
      </div>
      <div className="grid-2">
        <Field label={cfg.numberLabel} required>
          {text('idNumber', {
            className: 'mono',
            inputMode: cfg.numeric ? 'numeric' : 'text',
            placeholder: cfg.placeholder,
            onChange: (e) => {
              let v = e.target.value;
              if (cfg.numeric) v = v.replace(/\D/g, '');
              if (cfg.upper) v = v.toUpperCase();
              set({ idNumber: v });
            },
          })}
          {err('idNumber')}
        </Field>
        <Field label="Country of issue" required>{text('countryOfIssue')}{err('countryOfIssue')}</Field>
      </div>
      {cfg.detailLabel && (
        <Field label={cfg.detailLabel} required>
          {text('idTypeDetail', { placeholder: cfg.detailPlaceholder })}
          {err('idTypeDetail')}
        </Field>
      )}
      <div className="grid-3">
        <Field label="ID date of issue" required>{text('dateOfIssue', { type: 'date', max: today() })}{err('dateOfIssue')}</Field>
        <Field label="ID expiry date" required>{text('dateOfExpiry', { type: 'date' })}{err('dateOfExpiry')}</Field>
        <Field label="Date became BO" required>{text('dateBecameBo', { type: 'date', max: today() })}{err('dateBecameBo')}</Field>
      </div>
      <div className="grid-2">
        {showFile && (
          <Field label="Verified ID document" required>
            <input {...bind('file')} type="file" onChange={(e) => set({ file: e.target.files?.[0] || null })} />
            {err('file')}
          </Field>
        )}
        <Field label="Source of information" required>
          {select('sourceOfInformation', SOURCES_OF_INFORMATION)}
        </Field>
      </div>
      <Field label="Residential address" required>{text('residentialAddress')}{err('residentialAddress')}</Field>

      <div className="toggle-row">
        <div>
          <div className="t-label">Politically exposed person (PEP)</div>
          <div className="t-sub">PEP screening result — source of wealth is then mandatory</div>
        </div>
        <button type="button" role="switch" aria-checked={f.pep} aria-label="Politically exposed person (PEP)"
          className={`switch${f.pep ? ' on' : ''}`} onClick={() => set({ pep: !f.pep })} />
      </div>
      {f.pep && (
        <Field label="PEP details" required>{text('pepDetails')}{err('pepDetails')}</Field>
      )}
      <div className="toggle-row">
        <div>
          <div className="t-label">Sanctions screening completed</div>
          <div className="t-sub">Confirm this person has been screened against sanctions lists</div>
        </div>
        <button type="button" role="switch" aria-checked={f.sanctionsScreened} aria-label="Sanctions screening completed"
          className={`switch${f.sanctionsScreened ? ' on' : ''}`}
          onClick={() => set({ sanctionsScreened: !f.sanctionsScreened })} />
      </div>
      {err('sanctionsScreened')}
      <div className="grid-2">
        <Field label="Source of wealth" required={f.pep}>
          {text('sourceOfWealth', { placeholder: 'Obtained where required' })}
          {err('sourceOfWealth')}
        </Field>
        <Field label="Source of funds">{text('sourceOfFunds', { placeholder: 'Obtained where required' })}</Field>
      </div>
      <Field label="Additional information (any other information required by the Registrar)">
        <textarea {...bind('additionalInformation')} rows={3} style={{ width: '100%', font: 'inherit' }}
          value={f.additionalInformation} onChange={(e) => set({ additionalInformation: e.target.value })} />
      </Field>
    </>
  );
}
